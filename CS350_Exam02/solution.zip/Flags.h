// Comment to test individual method
//#define ALL 1

// Uncomment to test individual method
#define FINDPREDECESSOR 1     //
#define FINDNODEITERATIVELY 1   //
#define HEIGHT 1                //
