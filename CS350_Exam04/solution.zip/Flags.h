// Comment to test individual method
#define ALL 1

// Uncomment to test individual method
//#define ISMINHEAP 1     //
//#define REMOVE 1        //
