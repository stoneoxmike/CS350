// Comment to test individual method
//#define ALL 1

// Uncomment to test individual method
#define CONSTRUCTOR 1   //
#define DESTRUCTOR 1    //
#define ENQUEUE 1       //
#define DEQUEUE 1
#define ISEMPTY 1       //
#define MAKEEMPTY 1     //
